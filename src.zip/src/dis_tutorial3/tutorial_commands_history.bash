# These are some of the commands that were used during the tutorial. This file should not be run, it is to be used as a reference.
# Also there might be wrong commands.
