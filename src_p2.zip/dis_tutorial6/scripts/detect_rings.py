#!/usr/bin/python3

import rclpy
from rclpy.node import Node
import cv2
import numpy as np
import tf2_ros
import math
import time

from sensor_msgs.msg import Image, PointCloud2
from geometry_msgs.msg import PointStamped, Vector3, Pose
from cv_bridge import CvBridge, CvBridgeError
from visualization_msgs.msg import Marker, MarkerArray
from std_msgs.msg import String
from std_msgs.msg import ColorRGBA
from rclpy.qos import QoSDurabilityPolicy, QoSHistoryPolicy
from rclpy.qos import QoSProfile, QoSReliabilityPolicy
from sensor_msgs_py import point_cloud2 as pc2


from rclpy.duration import Duration as Dur ###!!!
import tf2_geometry_msgs as tfg
from tf2_ros import TransformException
from tf2_ros.buffer import Buffer
from tf2_ros.transform_listener import TransformListener
import tf_transformations

qos_profile = QoSProfile(
          durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
          reliability=QoSReliabilityPolicy.RELIABLE,
          history=QoSHistoryPolicy.KEEP_LAST,
          depth=1)

class RingDetector(Node):
    def __init__(self):
        super().__init__('transform_point')

        # Basic ROS stuff
        timer_frequency = 2
        timer_period = 1/timer_frequency

        # An object we use for converting images between ROS format and OpenCV format
        self.bridge = CvBridge()

        # Marker array object used for visualizations
        self.marker_array = MarkerArray()
        self.marker_num = 1

        # Subscribe to the image and/or depth topic
        self.image_sub = self.create_subscription(Image, "/oakd/rgb/preview/image_raw", self.image_callback, 1)
        self.depth_sub = self.create_subscription(Image, "/oakd/rgb/preview/depth", self.depth_callback, 1)
        self.pointcloud_sub = self.create_subscription(PointCloud2, "/oakd/rgb/preview/depth/points", self.pointcloud_callback, 10)
        self.ring_color_sub = self.create_subscription(String, 'ring_color', self.ring_color_callback, 10)

        # Publiser for the visualization markers
        # self.marker_pub = self.create_publisher(Marker, "/ring", QoSReliabilityPolicy.BEST_EFFORT)
        self.ring_pub = self.create_publisher(Marker, '/ring_pub', 10)
        self.initial_ring_pub = self.create_publisher(Marker, '/initial_pub', 10)


        # Object we use for transforming between coordinate frames
        # self.tf_buf = tf2_ros.Buffer()
        # self.tf_listener = tf2_ros.TransformListener(self.tf_buf)

        self.ring_color = None
        self.target_column = None
        self.location_pixels = []
        self.should_publish = False
        self.send_initial = True


        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # cv2.namedWindow("Binary Image", cv2.WINDOW_NORMAL)
        # cv2.namedWindow("Detected contours", cv2.WINDOW_NORMAL)
        # cv2.namedWindow("Detected rings", cv2.WINDOW_NORMAL)
        cv2.namedWindow("Depth window", cv2.WINDOW_NORMAL)     

    def check_if_ring(self, image):
        col_indexes = []
        location_pixels = []
        count = 0
        for row_ix in range(np.shape(image)[0]):
            if row_ix > np.shape(image)[0] / 2 or count >= 40:
                break
            found_color = False
            found_black = False
            start_col = None
            end_col = None
            for column_ix in range(np.shape(image)[1]):
                if not found_color:
                    if not np.array_equal(image[row_ix][column_ix], [0, 0, 0]):
                        start_col = column_ix
                        found_color = True
                elif found_color and not found_black:
                    if np.array_equal(image[row_ix][column_ix], [0, 0, 0]):
                        found_black = True
                elif found_color and found_black:
                    if not np.array_equal(image[row_ix][column_ix], [0, 0, 0]):
                        count += 1
                        end_col = column_ix
                        col_indexes.append((start_col + end_col) / 2)
                        location_pixels.append((row_ix, column_ix))

        print("COUNT", count)
        if count >= 40:
            return True, (np.sum(col_indexes) / len(col_indexes)), location_pixels[(len(location_pixels) // 3):]
        return False, None, []

    def transformCoordinates(self, x, y):
        # Create a PointStamped in the /base_link frame of the robot
        # The point is located 0.5m in from of the robot
        # "Stamped" means that the message type contains a Header
        point_in_robot_frame = PointStamped()
        point_in_robot_frame.header.frame_id = "/base_link"
        point_in_robot_frame.header.stamp = self.get_clock().now().to_msg()

        point_in_robot_frame.point.x = x
        point_in_robot_frame.point.y = y
        point_in_robot_frame.point.z = 0.

        # Now we look up the transform between the base_link and the map frames
        # and then we apply it to our PointStamped
        time_now = rclpy.time.Time()
        timeout = Dur(seconds=0.1)
        try:
            # An example of how you can get a transform from /base_link frame to the /map frame
            # as it is at time_now, wait for timeout for it to become available
            trans = self.tf_buffer.lookup_transform("map", "base_link", time_now, timeout)
            # self.get_logger().info(f"Looks like the transform is available.")

            # Now we apply the transform to transform the point_in_robot_frame to the map frame
            # The header in the result will be copied from the Header of the transform
            point_in_map_frame = tfg.do_transform_point(point_in_robot_frame, trans)
            # self.get_logger().info(f"We transformed a PointStamped!")

            return point_in_map_frame

        except TransformException as te:
            self.get_logger().info(f"Cound not get the transform: {te}")

            return None

    def ring_color_callback(self, msg):
        self.ring_color = msg.data
                        

    def image_callback(self, data):
        self.get_logger().info(f"I got a new image! Will try to find rings...")

        try:
            cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
        except CvBridgeError as e:
            print(e)

        hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)

        # Define range for bright green color in HSV
        lower_green = np.array([50, 100, 100])
        upper_green = np.array([70, 255, 255])

        lower_red1 = np.array([0, 110, 110])
        upper_red1 = np.array([10, 255, 255])
        lower_red2 = np.array([160, 110, 110])
        upper_red2 = np.array([180, 255, 255])

        lower_blue = np.array([90, 100, 100])
        upper_blue = np.array([130, 255, 255])

        self.target_column = None
        if self.ring_color == 'green':
            mask_green = cv2.inRange(hsv_image, lower_green, upper_green)
            output_image_green = cv2.bitwise_and(cv_image, cv_image, mask=mask_green)
            cv2.imshow("Bright Green Only", output_image_green)
            cv2.waitKey(3)

            value, column, self.location_pixels = self.check_if_ring(output_image_green)
            if value:
                print(f"Ring detected at column{column}")
                self.target_column = column

        elif self.ring_color == "red":
            mask1 = cv2.inRange(hsv_image, lower_red1, upper_red1)
            mask2 = cv2.inRange(hsv_image, lower_red2, upper_red2)
            mask_red = cv2.bitwise_or(mask1, mask2)
            output_image_red = cv2.bitwise_and(cv_image, cv_image, mask=mask_red)
            cv2.imshow("Bright Red Only", output_image_red)
            cv2.waitKey(3)

            value, column, self.location_pixels = self.check_if_ring(output_image_red)
            if value:
                print(f"Ring detected at column{column}")
                self.target_column = column

        elif self.ring_color == "blue":
            mask_blue = cv2.inRange(hsv_image, lower_blue, upper_blue)
            output_image_blue = cv2.bitwise_and(cv_image, cv_image, mask=mask_blue)
            cv2.imshow("Bright Blue Only", output_image_blue)
            cv2.waitKey(3)

            value, column, self.location_pixels == self.check_if_ring(output_image_blue)
            if value:
                print(f"Ring detected at column{column}")
                self.target_column = column


        

    def depth_callback(self, data):
        self.get_logger().info(f"I got a new depth image! Will try to find rings...")

        try:
            depth_image = self.bridge.imgmsg_to_cv2(data, "32FC1")
        except CvBridgeError as e:
            print(e)
            return

        depth_image[depth_image == np.inf] = 0

        # Normalize depth image for visualization
        image_1 = depth_image / np.max(depth_image) * 255
        image_viz = np.array(image_1, dtype=np.uint8)

        # Apply a binary threshold to get a binary image
        _, binary_image = cv2.threshold(image_viz, 50, 255, cv2.THRESH_BINARY)

        # Find contours in the binary image
        contours, _ = cv2.findContours(binary_image, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            # Approximate the contour to reduce the number of points
            epsilon = 0.01 * cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, epsilon, True)

            # Check if the contour is circular enough
            area = cv2.contourArea(contour)
            if area > 100:  # Minimum area to filter out noise
                ((x, y), radius) = cv2.minEnclosingCircle(contour)
                circularity = (4 * np.pi * area) / (cv2.arcLength(contour, True) ** 2)
                
                # Check if the shape is circular and has a hole (ring-like)
                if 0.7 < circularity < 1.2:
                    # Check if the center of the ring is within ±5 pixels of the given column
                    print("TARGET", self.target_column)
                    if self.target_column is not None and abs(x - self.target_column) <= 15:
                        # if self.send_initial:
                        #     self.initial_pub.publish(Marker())
                        #     self.send_initial = False
                        #     time.sleep(2)
                        #     return
                        self.should_publish = True
                        # Draw the contour and the center of the ring
                        cv_image = cv2.cvtColor(image_viz, cv2.COLOR_GRAY2BGR)
                        cv2.drawContours(cv_image, [contour], -1, (0, 255, 0), 2)
                        cv2.circle(cv_image, (int(x), int(y)), int(radius), (255, 0, 0), 2)
                        cv2.putText(cv_image, "Ring detected", (int(x) - 50, int(y) - 10),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

                        cv2.imshow("Depth window", cv_image)
                        cv2.waitKey(1)
                        return


        # If no ring is detected or it is not in the specified column, just show the depth image
        cv2.imshow("Depth window", image_viz)
        cv2.waitKey(1)

    def pointcloud_callback(self, data):

            # get point cloud attributes
            height = data.height
            width = data.width
            point_step = data.point_step
            row_step = data.row_step		

            # iterate over face coordinates
            for x,y in self.location_pixels:


                # get 3-channel representation of the poitn cloud in numpy format
                a = pc2.read_points_numpy(data, field_names= ("x", "y", "z"))
                a = a.reshape((height,width,3))

                # read center coordinates
                if y >= len(a):
                    y = 239
                if x >= len(a[0]):
                    x = 319
                d = a[x,y,:]

                if math.isinf(d[0]) or math.isinf(d[1]):
                    continue

                transCoords = self.transformCoordinates(float(d[0]), float(d[1]))

                # create marker
                marker = Marker()

                # marker.header.parking_image_id = "/base_link"
                marker.header.stamp = data.header.stamp

                marker.type = 2
                marker.id = 0 # We can make it so that the marker ID for the position of the face is 0, and the ID of the marker of the normal is 1

                # Set the scale of the marker
                scale = 0.1
                marker.scale.x = scale
                marker.scale.y = scale
                marker.scale.z = scale

                # Set the color
                marker.color.r = 1.0
                marker.color.g = 1.0
                marker.color.b = 1.0
                marker.color.a = 1.0

                # Set the pose of the marker
                marker.pose.position.x = float(transCoords.point.x)
                marker.pose.position.y = float(transCoords.point.y)
                marker.pose.position.z = float(0)

                if self.should_publish:
                    if transCoords is not None:
                        self.ring_pub.publish(marker)
                        print(f"PUBLISHED {transCoords.point.x}, {transCoords.point.y}")

                    self.should_publish = False
 
def main():

    rclpy.init(args=None)
    rd_node = RingDetector()

    rclpy.spin(rd_node)

    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()